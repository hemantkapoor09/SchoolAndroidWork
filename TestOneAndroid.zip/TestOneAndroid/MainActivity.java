package com.example.erkapoorz.testone;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;
    Button sendBtn;
    EditText txtphoneNo;
    EditText txtMessage;
    String phoneNo = "+1(416)123-4567";
    String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonSend = (Button) findViewById(R.id.buttonSub);
        buttonSend.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                sendSMSMessage();
            }
        });
    }

    void sendEmail()
    {

        EditText firstName = (EditText) findViewById(R.id.fName);
            String fName = firstName.getText().toString();

        EditText lastName = (EditText) findViewById(R.id.lName);
            String lName = lastName.getText().toString();
        EditText stuId = (EditText) findViewById(R.id.studentId);
            String sID = stuId.getText().toString();
        EditText subject = (EditText) findViewById(R.id.courseName);
            String course = subject.getText().toString();
        EditText addre = (EditText) findViewById(R.id.address);
            String sAddress = addre.getText().toString();
        EditText insEmail = (EditText) findViewById(R.id.emailInsu);
            String profEmail = insEmail.getText().toString();

        Log.i("Send email","");
        String[] TO = {profEmail};
        String[] CC = {""};

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL,TO);
        emailIntent.putExtra(Intent.EXTRA_CC,CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Student Registration");
        emailIntent.putExtra(Intent.EXTRA_TEXT,"Student "+fName+" "+lName+",Id: "+sID+" ,Registeerd in "+course+" course");

        try{
            startActivity(Intent.createChooser(emailIntent,"send mail.........."));
            finish();
            Log.i("Email has Been Sent","Sended!");
        } catch (android.content.ActivityNotFoundException ex){
            Toast.makeText(MainActivity.this,"NO EMail Client",Toast.LENGTH_LONG).show();
        }

    }
//
protected void sendSMSMessage() {
    phoneNo = txtphoneNo.getText().toString();
    message = txtMessage.getText().toString();

    if (ContextCompat.checkSelfPermission(this,
            Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.SEND_SMS)) {
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        }
    }
}

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {

        EditText firstName = (EditText) findViewById(R.id.fName);
        String fName = firstName.getText().toString();

        EditText lastName = (EditText) findViewById(R.id.lName);
        String lName = lastName.getText().toString();
        EditText stuId = (EditText) findViewById(R.id.studentId);
        String sID = stuId.getText().toString();
        EditText subject = (EditText) findViewById(R.id.courseName);
        String course = subject.getText().toString();
        EditText addre = (EditText) findViewById(R.id.address);
        String sAddress = addre.getText().toString();
        EditText insEmail = (EditText) findViewById(R.id.emailInsu);
        String profEmail = insEmail.getText().toString();
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNo, null, "Student "+fName+" "+lName+",Id: "+sID+" ,Registeerd in "+course+" course", null, null);
                    Toast.makeText(getApplicationContext(), "SMS sent.",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS faild, please BUY SMS aPI Now your email.", Toast.LENGTH_LONG).show();
                    sendEmail();
                    return;
                }
            }
        }
    }



    //
}