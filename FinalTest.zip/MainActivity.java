package com.example.erkapoorz.finaltest;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
//First Name is first two alphabets and lastname is reverse of firstname and email address is firstname+lastname jsut used this for purpose of dummy data
    private String[] fName={"ab","bc","cd","de","ef","fg","gh","hi","ij","jk"};
    private String[] lName={"ba","cb","dc","ed","fe","gf","hg","ih","ji","kj"};
    private String[] crdnumber ={"123456XXXX001","234561XXXX001","345612XXXX001","456123XXXX001","561234XXXX001","612345XXXX001","7890XXXX001","8907XXXX001","9078XXXX001","0789XXXX001"};
    private int[] balance = {2010,1247,7845,0214,3784,7842,31697,1247,3495,0304};
    private int[] limt = {2000,1000,4000,6000,100,200,300,400,500,800};
    private String[] emailOwner = {"abba@gmail.com","bccb@gmail.com","cddc@gmail.com","deed@gmail.com","effe@gmail.com","fggf@gmail.com","ghhg@gmail.com","hiih@gmail.com","ijji@gmail.com","jkkj@gmail.com"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonSend = (Button) findViewById(R.id.buttonCheck);
        buttonSend.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                checkCards();
            }
        });
    }

    void checkCards()
    {
        float[] ratio={};
        int[] toBeMailed={};
        String address = null;
        for(int i=0;i<10;i++)
        {
            ratio[i]= balance[i] / limt[i];
        }

        for(int i=0;i<10;i++)
        {
            if(ratio[i]<0.8)
            {
                toBeMailed[i]=i;
            }
        }
        int count = toBeMailed.length;
            String mess = "Toatal "+count+" Accounts should be warnned";
            Toast.makeText(MainActivity.this,mess,Toast.LENGTH_LONG).show();

        //Concatinating email adresses to send it in one go !
        for(int i=0;i<count;i++)
        {
            int temp = toBeMailed[i];
            address =  emailOwner[temp] + " , ";
        }

        ///Now mail

        Log.i("Send email","");
        String[] TO = {address};
        String[] CC = {""};

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL,TO);
        emailIntent.putExtra(Intent.EXTRA_CC,CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"Account Warrning");
        emailIntent.putExtra(Intent.EXTRA_TEXT,"Limit of Your Credit card is about to over Please pay the bill imideiately ! Thanks from XYZ bank");

        try{
            startActivity(Intent.createChooser(emailIntent,"send mail.........."));
            finish();
            Log.i("Email has Been Sent","Sended!");
        } catch (android.content.ActivityNotFoundException ex){
            Toast.makeText(MainActivity.this,"NO EMail Client",Toast.LENGTH_LONG).show();
        }

    }
}
